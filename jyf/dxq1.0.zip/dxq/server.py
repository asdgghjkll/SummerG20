import http.server
import socketserver
import os
import json
import psutil
from urllib.parse import urlparse, parse_qs
import urllib.parse

# Define server port
PORT = 8090


def get_files_recursive(drive):
    files = []
    for root, _, filenames in os.walk(drive):
        for filename in filenames:
            files.append(os.path.join(root, filename))
    return files


def search_files(keyword):
    search_result = {}
    drives = get_drives()
    for drive in drives:
        files = get_files_recursive(drive)
        for file in files:
            try:
                with open(file, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                    for line_num, line in enumerate(lines, start=1):
                        if keyword.lower() in line.lower():
                            result = {'line': line_num, 'content': line.strip()}
                            if file in search_result:
                                search_result[file].append(result)
                            else:
                                search_result[file] = [result]
            except OSError:
                # Handle file access errors
                continue
    return search_result


def save_file(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
            file_content = f.read()
        with open('saved_file.txt', 'w', encoding='utf-8') as f:
            f.write(file_content)
    except OSError:
        # Handle file access errors
        pass


# Create a simple HTTP request handler class
class MyRequestHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Access-Control-Allow-Origin', '*')  # Add CORS header
        super().end_headers()

    def handle_drives_request(self):
        drives = get_drives()
        drives_json = json.dumps(drives)
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(drives_json.encode())

    def handle_files_request(self):
        query_params = parse_qs(urlparse(self.path).query)
        drive = query_params.get('drive', [''])[0]
        files = get_files_recursive(drive)
        files_json = json.dumps(files)
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(files_json.encode())

    def handle_folders_request(self):
        query_params = parse_qs(urlparse(self.path).query)
        folder_path = query_params.get('path', [''])[0]  # Use 'path' instead of 'drive'
        entries = self.list_directory(folder_path)

        if entries is not None:
            # Convert the entries to a list of filenames
            files = [name for name, _ in entries]
            files_json = json.dumps(files)
            self.send_response(200)
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(files_json.encode())
        else:
            self.send_error(404, "No permission to list directory")

    def list_directory(self, path):
        try:
            list = os.listdir(path)
        except OSError:
            self.send_error(404, "No permission to list directory")
            return None

        entries = []
        for name in list:
            fullname = os.path.join(path, name)
            displayname = linkname = name
            if os.path.isdir(fullname):
                displayname = name + "/"
                linkname = os.path.join(self.path, name + "/")
            entries.append((displayname, linkname))

        return entries

    def format_directory(self, path, entries):
        page_title = f"Index of {path}"
        content = f"<h1>Index of {path}</h1>"
        content += "<hr>"
        content += "<ul>"

        for displayname, linkname in entries:
            content += f'<li><a href="{linkname}">{displayname}</a></li>'

        content += "</ul>"

        template = """
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>{page_title}</title>
        </head>
        <body>
            {content}
        </body>
        </html>
        """

        return template.format(page_title=page_title, content=content)

    def translate_path(self, path):
        path = path.split('?', 1)[0]
        path = path.split('#', 1)[0]
        path = os.path.normcase(path)
        path = os.path.abspath(path)
        return path

    def do_GET(self):
        if self.path == '/':
            self.send_front_html()
        elif self.path == '/drives':
            self.handle_drives_request()
        elif self.path.startswith('/files'):
            self.handle_files_request()
        elif self.path.startswith('/folders'):
            self.handle_folders_request()
        elif self.path.startswith('/search'):
            self.handle_search_request()
        elif self.path.startswith('/save'):
            self.handle_save_request()
        else:
            super().do_GET()

    def send_front_html(self):
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        with open(os.path.join(os.path.dirname(__file__), 'front.html'), 'r', encoding='utf-8') as file:
            self.wfile.write(file.read().encode('utf-8'))

    def handle_search_request(self):
        query_params = parse_qs(urlparse(self.path).query)
        keyword = query_params.get('keyword', [''])[0]
        search_result = search_files(keyword)
        search_result_json = json.dumps(search_result)
        self.send_response(200)
        self.send_header('Content-type', 'application/json')
        self.end_headers()
        self.wfile.write(search_result_json.encode())

    def handle_save_request(self):
        query_params = parse_qs(urlparse(self.path).query)
        file_path = query_params.get('path', [''])[0]
        file_path = urllib.parse.unquote(file_path)
        save_file(file_path)
        self.send_response(200)
        self.send_header('Content-type', 'text/html')
        self.end_headers()
        self.wfile.write(b'File saved successfully')


# Get drive information
def get_drives():
    drives = []
    partitions = []
    if os.name == 'nt':
        # If it's a Windows system
        partitions = psutil.disk_partitions(all=True)
    else:
        # If it's another operating system
        partitions = psutil.disk_partitions()

    for partition in partitions:
        if partition.fstype:  # Consider only partitions with file systems
            drives.append(partition.device)

    return drives


# Start the server
with socketserver.ThreadingTCPServer(("", PORT), MyRequestHandler) as httpd:
    print("Server running on port", PORT)
    httpd.serve_forever()
